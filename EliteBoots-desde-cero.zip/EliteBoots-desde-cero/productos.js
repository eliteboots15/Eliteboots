// PARA AÑADIR UNA BOTA: copia una línea, cambia el nombre y el archivo de imagen.
const PRODUCTOS = [
  { nombre: 'Nike Phantom blanco y negro', imagen: 'imagenes/nike-phantom-blanco-negro.jpeg' }
];
